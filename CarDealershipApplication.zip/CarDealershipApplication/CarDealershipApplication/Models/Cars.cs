﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarDealershipApplication.Models
{
    public class Cars
    {
        public string ID { get; set; }
        public string Make { get; set; }
        public string Color { get; set; }
        public string Year { get; set; }        
        public string SunRoof { get; set; }
        public string FourWheelDrive { get; set; }
        public string PowerWindows { get; set; }
        public string Navigation { get; set; }
        public string HeatedSeats { get; set; }
        public string Mileage { get; set; }
        public string Price { get; set; }

    }
}
