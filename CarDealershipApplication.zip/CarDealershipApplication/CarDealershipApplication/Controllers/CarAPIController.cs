﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using CarDealershipApplication.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Schema;


namespace CarDealershipApplication.Controllers
{
    [Route("api")]
    [ApiController]
    public class CarAPIController : ControllerBase
    {
        // GET: api/GetAllCars  
        [HttpGet]
        [Route("GetAllCars")]
        public IEnumerable<Cars> GetAllCars()
        {
            List<Cars> lstCars = new List<Cars>
           {
           new Cars{
                            ID="1001",
                            Make = "Chevy",
                              Color = "Gray",
                              Year = "2016",
                              SunRoof = "false",
                              FourWheelDrive = "true",
                              PowerWindows = "false",
                              Navigation = "true",
                              HeatedSeats = "false",
                              Mileage = "10000",
                              Price = "16000"
                              },
           new Cars{
                            ID="1002",
                            Make = "Toyota",
                              Color = "White",
                              Year = "2011",
                              SunRoof = "true",
                              FourWheelDrive = "false",
                              PowerWindows = "false",
                              Navigation = "false",
                              HeatedSeats = "true",
                              Mileage = "20000",
                              Price = "11000"
                              },

           };
            return lstCars;
        }

       
        [HttpGet]
        [Route("GetCarsByCriteria")]
        public IEnumerable<Cars> GetCarsByCriteria(string objData)
        {
            //Retrieve data from the input string parameter
            //Call repository method to retrieve data from the database
            //Populate and return list.
            List<Cars> lstCars = new List<Cars>
           {
           new Cars{
                            ID="1002",
                            Make = "Toyota",
                              Color = "White",
                              Year = "2011",
                              SunRoof = "true",
                              FourWheelDrive = "false",
                              PowerWindows = "false",
                              Navigation = "false",
                              HeatedSeats = "true",
                              Mileage = "20000",
                              Price = "11000"
                              },

           };
            return lstCars;
        }
    }
}